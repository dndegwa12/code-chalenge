package deetechalc.com.codechallenge

import android.app.Activity
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onButtonClick(v: View) {
        val myIntent = Intent(baseContext, ActivityB::class.java)
        startActivity(myIntent)
    }

    fun onButtonClick2(v: View) {
        val myIntent2 = Intent(baseContext, ActivityC::class.java)
        startActivity(myIntent2)
    }
}
